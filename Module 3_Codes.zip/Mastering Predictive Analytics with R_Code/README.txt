All the chapters in the book have code files.
IntroductionToR.R is the code file for the online chapter.